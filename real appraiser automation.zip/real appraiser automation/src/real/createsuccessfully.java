package real;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class createsuccessfully {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		//system setproperty for chromedriver and path
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Abdul Munaf\\Downloads\\chromedriver_win32\\chromedriver.exe");
		
		//object creation for chromedriver
		WebDriver driver = new ChromeDriver();
		
		//chrome appliation is used for this action maximize,manage,window,timeouts 
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		
		//url for project to open in web browser
		driver.get("https://dev-ra.usa.athenatec.com/#/access/home");
		
		//username getting
		driver.findElement(By.id("Username")).sendKeys("munaf@test.com");
		
		//password getting
		driver.findElement(By.id("Pwd")).sendKeys("Welcome@123");
		
		//for login for current url
		driver.findElement(By.xpath("//*[@id=\"app\"]/div/div/div/div/form/div[6]/button")).click();
		
		//for dropdown list in employee branch name
		//driver.findElement(By.xpath("/html/body/div[4]/div/div/div/div[1]/div/div[2]/div/div/div/div/button")).click();
		
		//driver.findElement(By.xpath("/html/body/div[4]/div/div/div/div[1]/div/div[2]/div/div/div/div/ul/li[6]/a")).click();
		
		//driver.findElement(By.xpath("/html/body/div[4]/div/div/div/div[1]/div/div[2]/div/div/div/div/button")).click();
	     
		//driver.findElement(By.xpath("/html/body/div[4]/div/div/div/div[1]/div/div[3]/button")).click();
		
		//sleep is meaning for waiting 
		Thread.sleep(10000);
		
		driver.findElement(By.xpath("//*[@id=\"app\"]/div[1]/div/div[2]/div/div/div/div[1]/ul/li[4]/a")).click();
		
		//application create for case - Application name 
		Select application = new Select(driver.findElement(By.name("namesalution")));
		
		application.selectByVisibleText("Mr.");
		
		driver.findElement(By.xpath("//*[@id=\"app\"]/div[2]/div[2]/div[1]/div/div[2]/div/div/form/div/div[1]/div/div[2]/div[1]/div/div/input")).sendKeys("Abdul automation testing case");
		
		//by selecting property type 
		Select s1 = new Select(driver.findElement(By.name("propertytype")));
		
		s1.selectByVisibleText("House");
		
		//for selection bank name
		Select s2 = new Select(driver.findElement(By.name("bank")));
		
		s2.selectByVisibleText("MRHFL AFFORDABLE HOME");
		
		//selection for bankbranch
		Select s3 = new Select(driver.findElement(By.name("bankbranch")));
		
		s3.selectByVisibleText("MRHFL AFFORDABLE HOME");
		
		Select s4 = new Select(driver.findElement(By.name("reporttype")));
		
		s4.selectByVisibleText("Land and Building");
		
		driver.findElement(By.xpath("//*[@id=\"app\"]/div[2]/div[2]/div[1]/div/div[2]/div/div/form/div/div[1]/div/div[3]/div[2]/textarea")).sendKeys("muggappair");
		
		driver.findElement(By.xpath("//*[@id=\"app\"]/div[2]/div[2]/div[1]/div/div[2]/div/div/form/div/div[1]/div/div[3]/div[3]/textarea")).sendKeys("chennai");
		
		driver.findElement(By.xpath("//*[@id=\"app\"]/div[2]/div[2]/div[1]/div/div[2]/div/div/form/div/div[1]/div/div[6]/div[2]/input")).sendKeys("boomi");

		driver.findElement(By.name("mobilez")).sendKeys("9940095343");
		
		Select s5 = new Select(driver.findElement(By.name("Name")));
		
		s5.selectByVisibleText("Valuation for Bank Loan / collateral mortgage.");
		
		driver.findElement(By.xpath("//*[@id=\"app\"]/div[2]/div[2]/div[1]/div/div[2]/div/div/form/div/div[1]/div/div[7]/div[1]/select")).click();
	      
		driver.findElement(By.xpath("//*[@id=\"app\"]/div[2]/div[2]/div[1]/div/div[2]/div/div/form/div/div[1]/div/div[7]/div[1]/select/option[2]")).click();
	      
	    driver.findElement(By.xpath("//*[@id=\"app\"]/div[2]/div[2]/div[1]/div/div[2]/div/div/form/div/div[1]/div/div[7]/div[1]/select")).click();

	    JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,300)");
	    Thread.sleep(10000);
	    
	    //field staff section in creating a case 
	    driver.findElement(By.xpath("//*[@id=\"ddlFieldstaff\"]/div/button")).click();
	    
	    driver.findElement(By.xpath("//*[@id=\"ddlFieldstaff\"]/div/ul/li[6]/a")).click();
	   
	    driver.findElement(By.xpath("//*[@id=\"ddlFieldstaff\"]/div/button")).click();
	    
	    Thread.sleep(10000);
	   
	    //report maker selection in create case 
	    driver.findElement(By.xpath("//*[@id=\"ddlReportMaker\"]/div/button")).click();
	    
	    driver.findElement(By.xpath("//*[@id=\"ddlReportMaker\"]/div/ul/li[6]/a")).click();
	    
	    driver.findElement(By.xpath("//*[@id=\"ddlReportMaker\"]/div/button")).click();
	    
	    js.executeScript("window.scrollBy(0,300)");
	    
	    Thread.sleep(10000);
	   
	    //submit button clicking 
	     driver.findElement(By.xpath("//*[@id=\"app\"]/div[2]/div[2]/div[1]/div/div[2]/div/div/form/div/footer/button[1]")).click();
	     
	     Thread.sleep(10000);
	     // ok button clicking 
	     driver.findElement(By.xpath("/html/body/div[4]/button[2]")).click();
	     
	     Thread.sleep(10000);
	     
	     //back
	     driver.findElement(By.xpath("//*[@id=\"app\"]/div[2]/div[2]/div[1]/div/div[2]/div/div/form/div/footer/button[2]")).click();
	     
	     Thread.sleep(10000);
	     
	     driver.findElement(By.xpath("//*[@id=\"app\"]/div[1]/div/div[2]/div/div/div/div[1]/ul/li[2]/a")).click();
	     
	     Thread.sleep(10000);
	     
	     //logout
	     driver.findElement(By.xpath("//*[@id=\"app\"]/div[1]/div/div[2]/div/div/div/div[1]/ul/li[26]/a/span")).click();
	     
	     driver.findElement(By.xpath("//*[@id=\"app\"]/div[1]/div/div[2]/div/div/div/div[1]/ul/li[26]/ul/li[4]/a")).click();
	     
	     Thread.sleep(10000);
	     
	     //username
	     driver.findElement(By.id("Username")).sendKeys("meenamulti@test.com");
			
			//password getting
		driver.findElement(By.id("Pwd")).sendKeys("Welcome@123");
		
		driver.findElement(By.xpath("//*[@id=\"app\"]/div/div/div/div/form/div[6]/button")).click();
		//Thread.sleep(10000);
		
		//driver.findElement(By.xpath("/html/body/div[4]/div/div/div/div[1]/div/div[2]/div/div/div/div/button")).click();
		
		//driver.findElement(By.xpath("/html/body/div[6]/div/div/div/div[1]/div/div[2]/div/div/div/div/ul/li[6]/a")).click();
		
		//driver.findElement(By.xpath("/html/body/div[4]/div/div/div/div[1]/div/div[2]/div/div/div/div/button")).click();
		
		//driver.findElement(By.className("btn btn-default")).click();
		
		driver.findElement(By.id("rbCustomer_5")).click();	
		
		Thread.sleep(10000);
		driver.findElement(By.xpath("//*[@id=\"app\"]/div[2]/div[2]/div/div[1]/div[2]/div/div/div/div[2]/div/div[1]/a/div/div")).click();
		
		//driver.findElement(By.id("6129")).click();
		Thread.sleep(10000);		
		driver.findElement(By.xpath("//*[@id=\"6133\"]/i")).click();
		
		//dasboard
		driver.findElement(By.xpath("//*[@id=\"app\"]/div[1]/div/div[2]/div/div/div/div[1]/ul/li[2]/a")).click();
		
		Thread.sleep(10000);
		driver.findElement(By.xpath("//*[@id=\"app\"]/div[2]/div[2]/div/div[1]/div[2]/div/div/div/div[2]/div/div[2]/a/div/div")).click();
		
		//this id inspection 
		Thread.sleep(10000);
		driver.findElement(By.xpath("//*[@id=\"6122\"]/i")).click();
		
		
		driver.findElement(By.xpath("/html/body/div[5]/button[2]")).click();
		
		driver.findElement(By.xpath("//*[@id=\"app\"]/div[2]/div[2]/div/div/div[2]/div/div/form/div/div[1]/div/div/fieldset/div/div/form/div[1]/fieldset[1]/div[2]/div/div[2]/div/label/input")).click();
		
		
	}

}
